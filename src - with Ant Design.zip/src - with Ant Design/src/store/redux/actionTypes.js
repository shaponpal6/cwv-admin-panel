export const ADD_TODO = "ADD_TODO";
export const TOGGLE_TODO = "TOGGLE_TODO";
export const SET_FILTER = "SET_FILTER";


export const APP_ROUTER = "APP_ROUTER";
export const ADD_MESSAGE = "ADD_MESSAGE";
export const SET_MESSAGES = "SET_MESSAGES";
export const SET_CLIENT_DATA = "SET_CLIENT_DATA";
export const SET_CLIENTS_LIST = "SET_CLIENTS_LIST";
export const SET_CLIENT_ID = "SET_CLIENT_ID";
export const ADD_KNOWLEDGE = "ADD_KNOWLEDGE";
