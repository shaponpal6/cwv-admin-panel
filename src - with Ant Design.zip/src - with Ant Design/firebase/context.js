import React from 'react';
 
const Context = React.createContext(null);
 
export default Context;