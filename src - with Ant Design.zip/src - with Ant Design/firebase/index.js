import FirebaseContext, { withFirebase } from './firebaseContext';
import Firebase from './firebase';
 
export default Firebase;
 
export { FirebaseContext, withFirebase };