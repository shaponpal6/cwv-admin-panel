export const ADD_TODO = "ADD_TODO";
export const TOGGLE_TODO = "TOGGLE_TODO";
export const SET_FILTER = "SET_FILTER";


export const APP_ROUTER = "APP_ROUTER";
export const ADD_MESSAGE = "ADD_MESSAGE";
export const SET_MESSAGES = "SET_MESSAGES";
export const SET_CLIENT_DATA = "SET_CLIENT_DATA";
export const SET_CLIENTS_LIST = "SET_CLIENTS_LIST";
export const SET_CLIENT_ID = "SET_CLIENT_ID";
export const SET_SHORT_NOTES = "SET_SHORT_NOTES";
export const SET_OPERATORS = "SET_OPERATORS";
export const ADD_KNOWLEDGE = "ADD_KNOWLEDGE";
